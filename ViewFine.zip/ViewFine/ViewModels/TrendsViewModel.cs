﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel; 

namespace ViewFine.ViewModels
{
    public partial class TrendsViewModel: ObservableObject
    {
    }
}
